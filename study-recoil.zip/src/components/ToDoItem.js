import React from 'react';

function ToDoItem({ item }) {
    console.log('item: ', item);
    return (
        <div>
            <p>Hello</p>
        </div>
    );
}

export default ToDoItem;